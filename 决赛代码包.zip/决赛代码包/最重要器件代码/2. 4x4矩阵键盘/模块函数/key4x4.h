#ifndef __key4x4_h__
#define __key4x4_h__
#include "common_type.h"
#include "delay.h"
#include "lcd12864.h"
sbit key_row1=P2^7;
sbit key_row2=P0^0;
sbit key_row3=P2^6;
sbit key_row4=P0^3;
sbit key_col1=P1^6;
sbit key_col2=P1^7;
sbit key_col3=P0^2;
sbit key_col4=P0^1;
void key4x4_init(void);
u8 key4x4_scan(void);
void key4x4_lcd_show(u8 key);
#endif
