#ifndef __common_type_h__
#define __common_type_h__

#include "STC8A8K64D4.H"

typedef unsigned char u8;
typedef unsigned int  u16;
typedef unsigned long u32;

#endif
