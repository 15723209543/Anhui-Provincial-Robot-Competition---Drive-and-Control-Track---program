#include "sht30.h"

static void sht30_i2c_start(void);
static void sht30_i2c_stop(void);
static bit sht30_i2c_write(u8 dat);
static u8 sht30_i2c_read(bit ack);

/**************************************************************************************
 * ��  �� : I2C��ʼ�ź�
 * ��  �� : ��
 * ����ֵ : ��
 **************************************************************************************/
static void sht30_i2c_start(void)
{
    sht30_sda=1; sht30_scl=1; delay_10us();
    sht30_sda=0; delay_10us(); sht30_scl=0;
}

/**************************************************************************************
 * ��  �� : I2Cֹͣ�ź�
 * ��  �� : ��
 * ����ֵ : ��
 **************************************************************************************/
static void sht30_i2c_stop(void)
{
    sht30_scl=0; sht30_sda=0; delay_10us();
    sht30_scl=1; delay_10us(); sht30_sda=1;
}

/**************************************************************************************
 * ��  �� : I2Cдһ���ֽ�
 * ��  �� : dat: ��д����
 * ����ֵ : 1Ӧ��ɹ�,0ʧ��
 **************************************************************************************/
static bit sht30_i2c_write(u8 dat)
{
    u8 i;
    bit ack;

    for(i=0;i<8;i++)
    {
        sht30_sda = (bit)(dat & 0x80);
        delay_10us(); sht30_scl=1; delay_10us(); sht30_scl=0;
        dat <<= 1;
    }
    sht30_sda=1; delay_10us(); sht30_scl=1; delay_10us();
    ack = !sht30_sda;
    sht30_scl=0;
    return ack;
}

/**************************************************************************************
 * ��  �� : I2C��һ���ֽ�
 * ��  �� : ack: 1����Ӧ��,0���ͷ�Ӧ��
 * ����ֵ : ��ȡ������
 **************************************************************************************/
static u8 sht30_i2c_read(bit ack)
{
    u8 i;
    u8 dat;

    dat=0; sht30_sda=1;
    for(i=0;i<8;i++)
    {
        dat <<= 1;
        sht30_scl=1; delay_10us();
        if(sht30_sda) dat |= 1;
        sht30_scl=0; delay_10us();
    }
    sht30_sda = !ack; delay_10us(); sht30_scl=1; delay_10us(); sht30_scl=0; sht30_sda=1;
    return dat;
}

/**************************************************************************************
 * ��  �� : SHT30��ʼ��
 * ��  �� : ��
 * ����ֵ : ��
 **************************************************************************************/
void sht30_init(void)
{
    P3M1 &= 0x3f; P3M0 &= 0x3f;
    delay_ms(100);
}

/**************************************************************************************
 * ��  �� : ��ȡSHT30��ʪ��
 * ��  �� : temperature�¶�ָ��, humidityʪ��ָ��
 * ����ֵ : 1�ɹ�,0ʧ��
 **************************************************************************************/
bit sht30_read(float *temperature, float *humidity)
{
    u8 buf[6];
    u16 raw_t;
    u16 raw_h;

    sht30_i2c_start();
    if(!sht30_i2c_write(0x88)){sht30_i2c_stop(); return 0;}
    sht30_i2c_write(0x2c);
    sht30_i2c_write(0x06);
    sht30_i2c_stop();
    delay_ms(20);
    sht30_i2c_start();
    if(!sht30_i2c_write(0x89)){sht30_i2c_stop(); return 0;}
    buf[0]=sht30_i2c_read(1); buf[1]=sht30_i2c_read(1); buf[2]=sht30_i2c_read(1);
    buf[3]=sht30_i2c_read(1); buf[4]=sht30_i2c_read(1); buf[5]=sht30_i2c_read(0);
    sht30_i2c_stop();
    raw_t=((u16)buf[0]<<8)|buf[1];
    raw_h=((u16)buf[3]<<8)|buf[4];
    *temperature = -45.0 + 175.0 * (float)raw_t / 65535.0;
    *humidity = 100.0 * (float)raw_h / 65535.0;
    return 1;
}

/**************************************************************************************
 * ��  �� : LCD12864��ʾSHT30��ʪ��
 * ��  �� : ��
 * ����ֵ : ��
 **************************************************************************************/
void sht30_lcd_show(void)
{
    float t;
    float h;
    bit ok;

    ok = sht30_read(&t,&h);
    lcd12864_show_string(0,0,"sht30 test");
    if(ok)
    {
        lcd12864_show_string(1,0,"temp:"); lcd12864_show_float1(1,3,t); lcd12864_show_string(1,7,"C");
        lcd12864_show_string(2,0,"humi:"); lcd12864_show_float1(2,3,h); lcd12864_show_string(2,7,"%");
    }
    else
    {
        lcd12864_show_string(1,0,"read error");
    }
}
