#ifndef __sht30_h__
#define __sht30_h__
#include "common_type.h"
#include "delay.h"
#include "lcd12864.h"
sbit sht30_scl=P3^7;
sbit sht30_sda=P3^6;
void sht30_init(void);
bit sht30_read(float *temperature, float *humidity);
void sht30_lcd_show(void);
#endif
