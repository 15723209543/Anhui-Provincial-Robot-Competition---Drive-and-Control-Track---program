#ifndef __at24c02_h__
#define __at24c02_h__
#include "common_type.h"
#include "delay.h"
#include "lcd12864.h"
sbit at24_scl=P7^7;
sbit at24_sda=P7^6;
void at24c02_init(void);
void at24c02_write_byte(u8 addr,u8 dat);
u8 at24c02_read_byte(u8 addr);
void at24c02_lcd_show(void);
#endif
