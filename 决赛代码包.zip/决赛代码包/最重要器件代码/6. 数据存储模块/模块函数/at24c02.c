#include "at24c02.h"

static void at24_start(void); static void at24_stop(void); static bit at24_write(u8 dat); static u8 at24_read(bit ack);
static void at24_start(void){at24_sda=1;at24_scl=1;delay_10us();at24_sda=0;delay_10us();at24_scl=0;}
static void at24_stop(void){at24_scl=0;at24_sda=0;delay_10us();at24_scl=1;delay_10us();at24_sda=1;}
static bit at24_write(u8 dat){u8 i;bit ack;for(i=0;i<8;i++){at24_sda=(bit)(dat&0x80);delay_10us();at24_scl=1;delay_10us();at24_scl=0;dat<<=1;}at24_sda=1;delay_10us();at24_scl=1;delay_10us();ack=!at24_sda;at24_scl=0;return ack;}
static u8 at24_read(bit ack){u8 i;u8 dat;dat=0;at24_sda=1;for(i=0;i<8;i++){dat<<=1;at24_scl=1;delay_10us();if(at24_sda)dat|=1;at24_scl=0;delay_10us();}at24_sda=!ack;delay_10us();at24_scl=1;delay_10us();at24_scl=0;at24_sda=1;return dat;}

/**************************************************************************************
 * ��  �� : AT24C02��ʼ��
 * ��  �� : ��
 * ����ֵ : ��
 **************************************************************************************/
void at24c02_init(void)
{
    P7M1 &= 0x3f; P7M0 &= 0x3f;
    at24_scl=1; at24_sda=1;
}

/**************************************************************************************
 * ��  �� : AT24C02дһ���ֽ�
 * ��  �� : addr��ַ, dat����
 * ����ֵ : ��
 **************************************************************************************/
void at24c02_write_byte(u8 addr,u8 dat)
{
    at24_start(); at24_write(0xa0); at24_write(addr); at24_write(dat); at24_stop(); delay_ms(10);
}

/**************************************************************************************
 * ��  �� : AT24C02��һ���ֽ�
 * ��  �� : addr��ַ
 * ����ֵ : ����������
 **************************************************************************************/
u8 at24c02_read_byte(u8 addr)
{
    u8 dat;
    at24_start(); at24_write(0xa0); at24_write(addr); at24_start(); at24_write(0xa1); dat=at24_read(0); at24_stop(); return dat;
}


