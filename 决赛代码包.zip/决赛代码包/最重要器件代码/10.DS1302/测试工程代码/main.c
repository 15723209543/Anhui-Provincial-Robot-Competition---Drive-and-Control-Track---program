#include "STC8A8K64D4.H"
#include "common_type.h"
#include "delay.h"
#include "lcd12864.h"
#include "ds1302.h"

/**************************************************************************************
 * ��  �� : ���DS1302ʱ��ģ�����������
 * ��  �� : ��
 * ����ֵ : ��
 **************************************************************************************/
void main(void)
{
    ds1302_time_t time;
    u8 ok;

    lcd12864_init();
    lcd12864_clear();
    lcd12864_show_string(0, 0, (u8 *)"DS1302 TEST    ");
    lcd12864_show_string(1, 0, (u8 *)"OUT MODULE ONLY");
    delay_ms(1000);

    ds1302_init();

//��ʼ����ɾ��
    while(1)
    {
        ok = ds1302_get_time(&time);
        if(ok)
        {
            ds1302_display_time(&time);
        }
        else
        {
            lcd12864_clear();
            lcd12864_show_string(0, 0, (u8 *)"DS1302 ERROR   ");
            lcd12864_show_string(1, 0, (u8 *)"CHECK P23 P25  ");
            lcd12864_show_string(2, 0, (u8 *)"CHECK P24 GND  ");
            lcd12864_show_string(3, 0, (u8 *)"NO BOARD RTC   ");
        }
        delay_ms(1000);
    }
}
