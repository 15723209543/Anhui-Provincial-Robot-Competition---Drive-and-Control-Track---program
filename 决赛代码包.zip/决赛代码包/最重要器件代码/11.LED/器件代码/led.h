#ifndef __LED_H__
#define __LED_H__

#include "STC8A8K64D4.H"
#include "common_type.h"
#include "delay.h"
#include "lcd12864.h"

sbit led_d1 = P4^2;     /* D1=P42������J29�� */
sbit led_d2 = P7^3;     /* D2=P73������J29�� */
sbit led_d3 = P6^0;     /* D3=P60��J29ѡ�� */
sbit led_d4 = P6^1;     /* D4=P61��J29ѡ�� */

#define led_1  1
#define led_2  2
#define led_3  3
#define led_4  4

void led_init(void);
void led_on(u8 led_idx);
void led_off(u8 led_idx);
void led_toggle(u8 led_idx);
void leds_on(void);
void leds_off(void);
void led_blink(void);

#endif
