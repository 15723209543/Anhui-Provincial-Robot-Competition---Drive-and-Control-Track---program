#ifndef __sg90_h__
#define __sg90_h__

#include "timer.h"
#include "lcd12864.h"

void sg90_init(void);
void sg90_set_0(void);
void sg90_set_45(void);
void sg90_set_90(void);
void sg90_set_135(void);
void sg90_set_180(void);
void sg90_show_state(u8 angle);
void sg90_task(void);

#endif
